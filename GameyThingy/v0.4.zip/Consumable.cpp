#include "Consumable.h"



Consumable::Consumable()
{
}


Consumable::~Consumable()
{
}

void Consumable::Update(float dt, bool isFullscreen)
{
}
