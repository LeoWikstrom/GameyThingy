#include "Item.h"

Item::Item()
{
}

Item::~Item()
{
}

void Item::Update(float dt, bool isFullscreen)
{
}
